#!/usr/bin/env python
# coding: utf-8

# In[1]:


from datetime import datetime, timedelta
import pytz
import re
import time

from pyspark.sql.functions import *
from pyspark.sql.types import FloatType


# In[2]:


spark.stop()
spark_builder = (SparkSession
                     .builder
                     .master('spark://spark-submit:7077')
                     .appName('pm-anomaly-adapter-notebook'))

spark_config={
                'spark.executor.memory': '8g',
                'spark.driver.memory': '8g',
                'spark.cores.max': 4,
                'spark.sql.autoBroadcastJoinThreshold': 52428800
            }

for key, val in spark_config.items():
    spark_builder.config(key, val)
    
spark = spark_builder.getOrCreate()
spark.sparkContext.addPyFile('/persistent/evshkar/Mobily/CSSR_2G_3G/anomaly.zip')


# In[3]:


from anomaly.common.pm.config_parser import get_configs
from anomaly.common.pm.formula_parser import parse_formula_file
from anomaly.common.pm.spark_cassandra import SparkCassandra
from anomaly.common.pm.spark_postgres import SparkPostgres
from anomaly.common.pm.constants import AppNameConstants, SparkCassandraConstants,     DataProcessingConstants


# In[4]:


scenario_id = 15
datetime_value = '2020-03-20 05:00'
historic_load = False


# In[5]:


scenario_id_str = str(scenario_id)
session_id = re.sub("[^0-9]", "", datetime_value)[:10]
cassandra_config, postgres_config, lcm_config, application_config =     get_configs(scenario_id_str)
spark_cassandra = SparkCassandra(spark, cassandra_config)
spark_postgres = SparkPostgres(spark, postgres_config)


# In[6]:


def segregate_schema(input_schema, output_schema, kpi_columns):
    common_schema = list(set(input_schema) & set(output_schema))
    select_schema = [column for column in common_schema
                     if column != DataProcessingConstants.COL_RECTIME]

    cols_to_aggregate = [column for column in select_schema
                         if column not in DataProcessingConstants.TARGET_GRAIN and
                         column not in DataProcessingConstants.COL_OSSMINS]
    cols_to_aggregate += kpi_columns

    return select_schema, cols_to_aggregate


# In[7]:


def construct_impute_dict(columns_to_aggregate, kpi_columns):
    impute_dict = {}
    for column in columns_to_aggregate:
        impute_dict[column] = None
    for column in kpi_columns:
        impute_dict[column] = -998
    return impute_dict


# In[8]:


def perform_transformations(df, formula_dict):
    for column, formula in formula_dict.items():
        df = df.withColumn(column, expr(formula))
    return df


# In[9]:


def aggregate_data(df, group_by, columns_to_aggregate,
                   use_default_aggregation_=True,
                   default_aggregation_method="sum",
                   aggregation_methods=()
                   ):
    if use_default_aggregation_:
        aggregation_methods = [default_aggregation_method] * len(columns_to_aggregate)

    sum_expr = {col_name: aggregation_methods[index]
                for index, col_name in enumerate(columns_to_aggregate)}
    df = df.groupBy(group_by).agg(sum_expr)

    for index, old_column in enumerate(columns_to_aggregate):
        new_column = aggregation_methods[index] + "(" + old_column + ")"
        df = df.withColumnRenamed(new_column, old_column)
    
    return df


# In[10]:


def join_data(source_df, lookup_df, use_broadcast_for_lookup, join_columns, join_type="inner"):
    if use_broadcast_for_lookup:
        df = source_df.join(broadcast(lookup_df), on=join_columns, how=join_type)
    else:
        df = source_df.join(lookup_df, on=join_columns, how=join_type)
    return df


# In[11]:


def rename_columns(source_df, old_columns, new_columns):
    for index, old_col in enumerate(old_columns):
        source_df = source_df.withColumnRenamed(old_col, new_columns[index])
    return source_df


# In[12]:


def get_data(table_, keyspace_):
    source_df = spark_cassandra.read_cassandra_table(
        table=table_,
        keyspace=keyspace_)
    return source_df


# In[13]:


def write_data(df_, table_, keyspace_, mode_, truncate_=False):
    spark_cassandra             .write_cassandra_table(df=df_, table=table_, keyspace=keyspace_,
                                   write_mode=mode_, truncate=truncate_)


# In[14]:


def get_lookup_cell_data():
    output_columns = [DataProcessingConstants.COL_VENDOR,
                      DataProcessingConstants.COL_TECHNOLOGY,
                      DataProcessingConstants.COL_CELLSTATUS,
                      DataProcessingConstants.COL_CELLID,
                      DataProcessingConstants.COL_SITEID
                      ]

    cell_df = spark_postgres.read_postgres_table(
        table=postgres_config.postgres_cell_table,
        database=postgres_config.postgres_database,
        columns=[DataProcessingConstants.COL_VENDOR, DataProcessingConstants.COL_TECHNOLOGY,
                 DataProcessingConstants.COL_CELLSTATUS, DataProcessingConstants.COL_CELL_ID,
                 DataProcessingConstants.COL_SITE_ID],
        renamed_columns=output_columns
    )

    select_expression = ["lower(" + DataProcessingConstants.COL_VENDOR + ")",
                         "lower(" + DataProcessingConstants.COL_TECHNOLOGY + ")",
                         DataProcessingConstants.COL_CELLSTATUS,
                         DataProcessingConstants.COL_CELLID,
                         DataProcessingConstants.COL_SITEID]

    cell_df_transformed = cell_df         .selectExpr(select_expression)         .toDF(*output_columns)         .filter((col(DataProcessingConstants.COL_CELLSTATUS)
                 .isin(DataProcessingConstants.ACTIVE_CELL_STATUS)) &
                (col(DataProcessingConstants.COL_VENDOR) ==
                 DataProcessingConstants.SCENARIO_LOOKUP[scenario_id][0]) &
                (col(DataProcessingConstants.COL_TECHNOLOGY) ==
                 DataProcessingConstants.SCENARIO_LOOKUP[scenario_id][1]))

    return cell_df_transformed


# In[15]:


def get_lookup_site_data():
    site_df = spark_postgres.read_postgres_table(
        table=postgres_config.postgres_site_table,
        database=postgres_config.postgres_database,
        columns=[DataProcessingConstants.COL_SITE_ID, DataProcessingConstants.COL_REGION,
                 DataProcessingConstants.COL_CLUSTER]
    )

    site_df_transformed = site_df         .withColumn(DataProcessingConstants.COL_TOWNSHIP,
                    split(site_df[DataProcessingConstants.COL_CLUSTER], '/')[1]) \
        .withColumnRenamed(DataProcessingConstants.COL_SITE_ID,
                           DataProcessingConstants.COL_SITEID)

    return site_df_transformed


# In[16]:


def compute_date_filters(datetime_value_):
    prev_timestamp =         datetime.strptime(datetime_value_,
                          DataProcessingConstants.INPUT_DATETIME_FMT) + timedelta(hours=-1)
    date_value = prev_timestamp         .date().strftime(application_config.data_processing.input_ossdate_fmt)
    hour_value = prev_timestamp.hour
    if application_config.data_processing.osshour_format == 'string':
        hour_value = str(hour_value)

    minutes_list = []
    if application_config.data_processing.source_grain == 'M':
        minutes_list = list(range(0, 60, application_config.data_processing.step_size))
        if application_config.data_processing.ossmins_format == 'string':
            minutes_list = [str(minute_value) for minute_value in minutes_list]
    return date_value, hour_value, minutes_list


# In[17]:


def compute_imputed_date_values(datetime_value_):
    prev_timestamp =         datetime.strptime(datetime_value_,
                          DataProcessingConstants.INPUT_DATETIME_FMT) + timedelta(hours=-1)
    utc = pytz.utc
    input_tz = pytz.timezone(DataProcessingConstants.TIMEZONE_LOOKUP[
            application_config.data_processing.input_timezone])
    input_dt = datetime.strptime(
        prev_timestamp.strftime(DataProcessingConstants.DATE_HOUR_FMT),
        DataProcessingConstants.DATE_HOUR_FMT)
    input_dttm = input_tz.localize(input_dt)
    utc_dttm = input_dttm.astimezone(utc)
    date_value_impute = utc_dttm.date().strftime(DataProcessingConstants.OUTPUT_DATE_FMT)
    hour_value_impute = utc_dttm.hour
    if application_config.data_processing.source_grain == 'M' and             application_config.data_processing.ceil_imputed_hour == 1:
        utc_dttm = utc_dttm + timedelta(hours=1)
        date_value_impute = utc_dttm.date().strftime(DataProcessingConstants.OUTPUT_DATE_FMT)
        hour_value_impute = utc_dttm.hour
    return date_value_impute, hour_value_impute


# In[18]:


def filter_source_data(input_df):
    date_value, hour_value, minutes_list = compute_date_filters(datetime_value)

    input_df = input_df.where((col(DataProcessingConstants.COL_OSSDATE) == date_value)
                              & (col(DataProcessingConstants.COL_OSSHOUR) == hour_value))

    if application_config.data_processing.source_grain == 'M':
        input_df = input_df.filter(col(DataProcessingConstants.COL_OSSMINS).isin(minutes_list))

    return input_df


# In[19]:


def impute_data(input_df, cell_master_df, columns_to_aggregate, kpi_columns):

    date_value_impute, hour_value_impute = compute_imputed_date_values(datetime_value)
    impute_dict = construct_impute_dict(columns_to_aggregate, kpi_columns)

    missing_df = cell_master_df         .select(DataProcessingConstants.COL_CELLID, DataProcessingConstants.COL_SITEID)         .subtract(input_df.select(DataProcessingConstants.COL_CELLID,
                                  DataProcessingConstants.COL_SITEID))

    imputed_df = missing_df         .withColumn(DataProcessingConstants.COL_OSSDATE, lit(date_value_impute))         .withColumn(DataProcessingConstants.COL_OSSHOUR, lit(hour_value_impute))

    for column, value in impute_dict.items():
        imputed_df = imputed_df.withColumn(column, lit(value).cast(FloatType()))

    output_df = input_df.union(imputed_df.select(input_df.columns))

    return output_df


# In[20]:


def postprocess_data(input_df):
    timestamp = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

    output_df = rename_columns(input_df,
                                    old_columns=[DataProcessingConstants.COL_REGION,
                                                 DataProcessingConstants.COL_CLUSTER,
                                                 DataProcessingConstants.COL_TOWNSHIP],
                                    new_columns=[DataProcessingConstants.COL_SERVICEAREA1,
                                                 DataProcessingConstants.COL_SERVICEAREA2,
                                                 DataProcessingConstants.COL_SERVICEAREA3]
                                    )

    output_df = output_df.withColumn(DataProcessingConstants.COL_OSSMINS, lit(0))         .withColumn(DataProcessingConstants.COL_RECTIME,
                    unix_timestamp(lit(timestamp), 'yyyy-MM-dd HH:mm:ss').cast("timestamp"))

    return output_df


# In[21]:


input_df = spark.read.option("header","true").csv('/persistent/evshkar/Mobily/data/pm/ericsson_3g/*.csv')


# In[22]:


cell_df = spark.read.option("header","true").csv('/persistent/evshkar/Mobily/data/pm/cell_3g/*.csv')
site_df = spark.read.option("header","true").csv('/persistent/evshkar/Mobily/data/pm/site/*.csv')


# In[23]:


target_df_columns = ['ossdate',
 'osshour',
 'siteid',
 'cellid',
 'ossmins',
 'pmsumamr12200rabestablish',
 'pmsumamr4750rabestablish',
 'pmsumamr5900rabestablish',
 'pmsumamr7950rabestablish',
 'pmsumbestamr12200rabestablish',
 'pmsumbestamrnbmmrabestablish',
 'pmsumbestamrwbrabestablish',
 'pmsumbestcs12establish',
 'pmsumbestcs57rabestablish',
 'pmsumbestcs64rabestablish',
 'rectime',
 'servicearea1',
 'servicearea2',
 'servicearea3',
 'servicearea4',
 'voice_traffic_kpi']


# In[24]:


if historic_load:
    input_df_filtered = input_df
else:
    input_df_filtered = filter_source_data(input_df)


# In[25]:


input_df_filtered.filter(col('cellid')=='UXTF3917H') .select("ossdate", "osshour", "cellid", "siteid", "pmsumbestamrwbrabestablish", 
        "pmsumbestcs12establish", "pmsumbestamr12200rabestablish", "pmsumbestamrnbmmrabestablish") \
.show(10, False)


# In[26]:


preprocessing, derivation, kpi_calculation =                 parse_formula_file(application_config.data_processing.formula_file)
select_schema, columns_to_aggregate =     segregate_schema(input_df.columns, target_df_columns, kpi_calculation.keys())


# In[27]:


preprocessed_df = perform_transformations(input_df_filtered, preprocessing)
derived_df = perform_transformations(preprocessed_df, derivation)
kpi_calculated_df = perform_transformations(derived_df, kpi_calculation)


# In[28]:


kpi_calculated_df.filter(col('cellid')=='UXTF3917H') .select("ossdate", "osshour", "cellid", "siteid", "pmsumbestamrwbrabestablish", 
        "pmsumbestcs12establish", "pmsumbestamr12200rabestablish", "pmsumbestamrnbmmrabestablish", "voice_traffic_kpi") \
.show(10, False)


# In[29]:


if application_config.data_processing.source_grain == 'M':

    aggregated_df = aggregate_data(kpi_calculated_df,
                                        DataProcessingConstants.TARGET_GRAIN,
                                        columns_to_aggregate,
                                        use_default_aggregation_=True
                                        )
else:
    aggregated_df = kpi_calculated_df.select(
        select_schema + list(kpi_calculation.keys()))


# In[30]:


aggregated_df.filter(col('cellid')=='UXTF3917H') .select("ossdate", "osshour", "cellid", "siteid", "pmsumbestamrwbrabestablish", 
        "pmsumbestcs12establish", "pmsumbestamr12200rabestablish", "pmsumbestamrnbmmrabestablish", "voice_traffic_kpi") \
.show(10, False)


# In[31]:


if historic_load:
    imputed_df = aggregated_df
else:
    imputed_df = impute_data(aggregated_df, cell_df, columns_to_aggregate,
                                  kpi_calculation.keys())


# In[32]:


enriched_df = join_data(imputed_df, site_df, use_broadcast_for_lookup=True,
                                         join_columns=[DataProcessingConstants.COL_SITEID])


# In[33]:


enriched_df.filter(col('cellid')=='UXTF3917H').show(10, False)


# In[34]:


final_df = postprocess_data(enriched_df)


# In[35]:


final_df.filter(col('cellid')=='UXTF3917H').show(10, False)


# In[ ]:




