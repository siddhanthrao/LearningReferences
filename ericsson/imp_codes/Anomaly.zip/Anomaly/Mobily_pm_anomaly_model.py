#!/usr/bin/env python
# coding: utf-8

# In[1]:


from datetime import datetime, timedelta
import os
import re
import sys
import time

from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType
from pyspark.sql.window import Window


# In[3]:


spark.stop()
spark_builder = (SparkSession
                     .builder
                     .master('spark://spark-submit:7077')
                     .appName('pm-anomaly-model-notebook'))

spark_config={
                'spark.executor.memory': '8g',
                'spark.driver.memory': '8g',
                'spark.cores.max': 4,
                'spark.sql.autoBroadcastJoinThreshold': 52428800
            }

for key, val in spark_config.items():
    spark_builder.config(key, val)
    
spark = spark_builder.getOrCreate()
spark.sparkContext.addPyFile('/persistent/evshkar/Mobily/CSSR_2G_3G/anomaly.zip')


# In[4]:


from anomaly.common.pm.config_parser import get_configs
from anomaly.common.pm.spark_cassandra import SparkCassandra
from anomaly.common.pm.constants import AppNameConstants, AnomalyDetectionConstants,     SparkCassandraConstants


# In[5]:


scenario_id = 15
datetime_value = '2020-03-29 05:00'


# In[6]:


scenario_id_str = str(scenario_id)
datetime_value = datetime_value
date_time = datetime.strptime(datetime_value, '%Y-%m-%d %H:%M')     .replace(minute=0, second=0, microsecond=0)
date_time_str = date_time.strftime("%Y-%m-%d %H:%M")


# In[7]:


cassandra_config, postgres_config, lcm_config, application_config =             get_configs(scenario_id_str)
spark_cassandra = SparkCassandra(spark, cassandra_config)


# In[8]:


cell_stats_input_location =     application_config.anomaly_detection.ctad_home +     AnomalyDetectionConstants.STATS_DIRECTORY + '/' + str(scenario_id) + '/' +     application_config.anomaly_detection.latest_cellwise_stats_folder +     AnomalyDetectionConstants.CELL_STATS_DIRECTORY
cell_hour_stats_input_location =     application_config.anomaly_detection.ctad_home +     AnomalyDetectionConstants.STATS_DIRECTORY + '/' + str(scenario_id) + '/' +     application_config.anomaly_detection.latest_cellhour_stats_folder +     AnomalyDetectionConstants.CELL_HOUR_STATS_DIRECTORY


# In[9]:


def trunc_decimal(value):
    ten_pow_n = pow(lit(10), AnomalyDetectionConstants.NUM_DIGITS_PRECISION)         .cast(AnomalyDetectionConstants.LONG_DATATYPE)
    return (((value * ten_pow_n).cast('long')) / ten_pow_n).cast("decimal(38,2)")


# In[10]:


def convert_list_to_array(value):
    return concat(lit('['), concat_ws(",", value), lit(']'))


# In[11]:


def last_element(value):
    return value[size(value) - 1]


# In[12]:


def convert_to_camelcase(value):
    value_tmp = value.title().replace("_", "")
    return value_tmp[:1].lower() + value_tmp[1:]


# In[13]:


def strip_whitespace(txt):
    return '"'.join(it if i % 2
                    else ''.join(it.split()) for i, it in enumerate(txt.split('"'))) \
        .replace(",", ", ")


# In[14]:


def parse_alarms_config_file(fm_alarms_config):
    """ Utility method to read the alarms config file. """
    outage_problem_list = [config_record.strip()
                           for config_record in open(fm_alarms_config).readlines()]
    return outage_problem_list


# In[15]:


def rename_columns(source_df, old_columns, new_columns):
    for index, old_col in enumerate(old_columns):
        source_df = source_df.withColumnRenamed(old_col, new_columns[index])
    return source_df


# In[16]:


def join_data(source_df, lookup_df, use_broadcast_for_lookup, join_columns, join_type="inner"):
    if use_broadcast_for_lookup:
        df = source_df.join(broadcast(lookup_df), on=join_columns, how=join_type)
    else:
        df = source_df.join(lookup_df, on=join_columns, how=join_type)
    return df


# In[17]:


def write_csv(df, output_location):
    df.write.options(**AnomalyDetectionConstants.WRITE_OPTIONS)         .csv("{}".format(output_location))


# In[18]:


def get_data(table_, keyspace_):
    source_df = spark_cassandra.read_cassandra_table(
        table=table_,
        keyspace=keyspace_)
    return source_df


# In[19]:


def write_data(df_, table_, keyspace_, mode_, truncate_=False):
    spark_cassandra             .write_cassandra_table(df=df_, table=table_, keyspace=keyspace_,
                                   write_mode=mode_, truncate=truncate_)


# In[20]:


def read_csv(path, options):
    df = spark.read.options(**options)         .csv(path)
    return df


# In[21]:


def filter_source_data(input_df):
    num_hours_to_extract = application_config.anomaly_detection.window_size + 29

    filter_criteria = False
    for index, value in enumerate(range(1, num_hours_to_extract + 1)):
        date_value = (date_time - timedelta(hours=value)).date()
        hour_value = (date_time - timedelta(hours=value)).hour

        if index == 0:
            filter_criteria = ((col(AnomalyDetectionConstants.COL_OSSDATE) == date_value) &
                               (col(AnomalyDetectionConstants.COL_OSSHOUR) == hour_value))
        else:
            filter_criteria = filter_criteria |                               ((col(AnomalyDetectionConstants.COL_OSSDATE) == date_value) &
                               (col(AnomalyDetectionConstants.COL_OSSHOUR) == hour_value))

    filtered_df = input_df.filter(filter_criteria)         .select(application_config.anomaly_detection.common_db_input_ad.split(","))

    return filtered_df


# In[22]:


def get_cell_stats_data():
    """ Retrieving Stats (cell wise) method """
    cell_stats_df = read_csv(os.path.realpath(cell_stats_input_location),
                                  AnomalyDetectionConstants.READ_OPTIONS_STATS)

    if cell_stats_df.limit(1).count() == 0:
        schema = StructType([
            StructField(AnomalyDetectionConstants.COL_CELLNAME, StringType()),
            StructField(AnomalyDetectionConstants.COL_CELL_WISE_MEDIAN, DoubleType()),
            StructField(AnomalyDetectionConstants.COL_CELL_WISE_AVG, DoubleType())
        ])
        cell_stats_df = spark.createDataFrame([], schema)

    return cell_stats_df


# In[23]:


def get_cell_hour_stats_data():
    """ Retrieving Stats (cell hour wise) method """
    cell_hour_stats_df = read_csv(os.path.realpath(cell_hour_stats_input_location),
                  AnomalyDetectionConstants.READ_OPTIONS_STATS) \
    if cell_hour_stats_df.limit(1).count() == 0:
        schema = StructType([
            StructField(AnomalyDetectionConstants.COL_CELLNAME, StringType()),
            StructField(AnomalyDetectionConstants.COL_OSSHOUR, IntegerType()),
            StructField(AnomalyDetectionConstants.COL_CELL_HOURLY_AVG, DoubleType()),
            StructField(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV, DoubleType()),
            StructField(AnomalyDetectionConstants.COL_CELL_HOURLY_MEDIAN, DoubleType())
        ])
        cell_hour_stats_df = spark.createDataFrame([], schema)

    cell_hour_stats_df = cell_hour_stats_df         .withColumn(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV,
                    round(col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV), 2))

    return cell_hour_stats_df


# In[24]:


def filter_fm_alarms_data(input_df):
    """ Get FM Alarms data and filter out data pertaining to Outage alarms"""
    num_hours_to_extract = application_config.anomaly_detection.window_size + 1

    lower_bound_datetime = (date_time - timedelta(hours=num_hours_to_extract))         .strftime("%Y%m%d %H%M%S")
    upper_bound_datetime = date_time.strftime("%Y%m%d %H%M%S")


    filter_criteria_fm = ((col(AnomalyDetectionConstants.COL_LASTOCCURRENCE) >=
                           lower_bound_datetime)
                          & (col(AnomalyDetectionConstants.COL_LASTOCCURRENCE) <
                             upper_bound_datetime))

    outage_problem_list = parse_alarms_config_file(
        application_config.anomaly_detection.fm_alarms_config)

    filter_criteria_fm = filter_criteria_fm         & (col(AnomalyDetectionConstants.COL_X733SPECIFICPROB).isin(outage_problem_list))

    fm_sites_list = spark.read.option("header","true").csv("/persistent/dev/notebook/data/pm/fm_alarms")         .filter(filter_criteria_fm)         .select(AnomalyDetectionConstants.COL_SITEID)         .distinct().rdd.map(lambda x: x[AnomalyDetectionConstants.COL_SITEID]).collect()

    if len(outage_problem_list) == 0:
        input_df_filtered = input_df
    else:
        input_df_filtered = input_df.filter(~col(AnomalyDetectionConstants.COL_SITEID)
                                            .isin(fm_sites_list))

    return input_df_filtered


# In[25]:


def preprocess_data(input_df):
    processed_df = rename_columns(
        input_df, old_columns=[AnomalyDetectionConstants.COL_SITEID,
                               AnomalyDetectionConstants.COL_CELLID,
                               AnomalyDetectionConstants.COL_SERVICEAREA1,
                               AnomalyDetectionConstants.COL_SERVICEAREA2,
                               AnomalyDetectionConstants.COL_SERVICEAREA3,
                               application_config.anomaly_detection.kpi_column
                               ],
        new_columns=[AnomalyDetectionConstants.COL_SITE_ID,
                     AnomalyDetectionConstants.COL_CELLNAME,
                     AnomalyDetectionConstants.COL_REGION,
                     AnomalyDetectionConstants.COL_CLUSTER,
                     AnomalyDetectionConstants.COL_TOWNSHIP,
                     AnomalyDetectionConstants.COL_KPI_ACTUAL
                     ]
        )

    processed_df = processed_df         .withColumn(AnomalyDetectionConstants.COL_TIMESTAMP,
                    from_unixtime(unix_timestamp(
                        concat(col(AnomalyDetectionConstants.COL_OSSDATE), lit(" "),
                               lpad(col(AnomalyDetectionConstants.COL_OSSHOUR), 2, '0')),
                        AnomalyDetectionConstants.TIMESTAMP_INPUT_FORMAT),
                      AnomalyDetectionConstants.TIMESTAMP_OUTPUT_FORMAT)) \
        .withColumn(AnomalyDetectionConstants.COL_KPI,
                    when(col(AnomalyDetectionConstants.COL_KPI_ACTUAL) < 0, 0)
                    .otherwise(col(AnomalyDetectionConstants.COL_KPI_ACTUAL)))

    return processed_df


# In[26]:


def compute_zscores(input_df, cell_hour_stats_df):
    """ Zscore calculation """
    zscore_df = join_data(input_df, cell_hour_stats_df, use_broadcast_for_lookup=True,
                               join_columns=[AnomalyDetectionConstants.COL_CELLNAME,
                                             AnomalyDetectionConstants.COL_OSSHOUR],
                               join_type=AnomalyDetectionConstants.LEFT_OUTER_JOIN)

    zscore_df = zscore_df.fillna(0, subset=[AnomalyDetectionConstants.COL_CELL_HOURLY_AVG])         .fillna(1, subset=[AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV])         .withColumn(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV,
                    when(col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV) == 0, 1)
                    .otherwise(col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV))) \
        .withColumn(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR,
                    ((col(AnomalyDetectionConstants.COL_KPI) -
                      col(AnomalyDetectionConstants.COL_CELL_HOURLY_AVG)) /
                     col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV)))

    return zscore_df


# In[27]:


def compute_scaled_zscores(input_df, cell_stats_df):
    """ Scaled Zscore calculation """
    scaled_input_df = join_data(input_df, cell_stats_df, use_broadcast_for_lookup=True,
                                join_columns=[AnomalyDetectionConstants.COL_CELLNAME])

    zscore_scaled_df = scaled_input_df         .withColumn(AnomalyDetectionConstants.COL_IS_ANOMALY,
                    when(((col(AnomalyDetectionConstants.COL_KPI) == 0) &
                          ((col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR) <
                            application_config.anomaly_detection.lower_bound_for_zero_kpi)
                           |
                           (col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR) >
                            application_config.anomaly_detection.higher_bound_for_zero_kpi)
                           )),
                         1)
                    .when(((col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR) <
                            application_config.anomaly_detection.lower_bound) |
                           (col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR) >
                            application_config.anomaly_detection.higher_bound)), 1)
                    .otherwise(0)) \
        .withColumn(AnomalyDetectionConstants.COL_DIRECTION,
                    when(col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR) > 0, 1)
                    .otherwise(-1)) \
        .withColumn(AnomalyDetectionConstants.COL_ZSCORE_ABS,
                    col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR) *
                    col(AnomalyDetectionConstants.COL_DIRECTION)) \
        .withColumn(AnomalyDetectionConstants.COL_ZSCORE_SCALED_AVG,
                    (col(AnomalyDetectionConstants.COL_ZSCORE_ABS) *
                     col(AnomalyDetectionConstants.COL_CELL_WISE_AVG)))

    return zscore_scaled_df


# In[28]:


def compute_sustained_zscores(input_df):
    sustained_input_df = input_df         .withColumn(AnomalyDetectionConstants.COL_TIMESTAMP_EPOCH,
                    col(AnomalyDetectionConstants.COL_TIMESTAMP)
                    .cast(AnomalyDetectionConstants.TIMESTAMP_DATATYPE)
                    .cast(AnomalyDetectionConstants.LONG_DATATYPE))

    windowspec = Window         .partitionBy(AnomalyDetectionConstants.COL_CELLNAME)         .orderBy(AnomalyDetectionConstants.COL_TIMESTAMP_EPOCH)         .rangeBetween(-1 * application_config.anomaly_detection.window_size * 3600, 0)

    windowspec_for_anomalous_cells = Window         .partitionBy(AnomalyDetectionConstants.COL_CELLNAME)         .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)

    zscore_sustained_df = sustained_input_df         .withColumn(AnomalyDetectionConstants.COL_AVG_FOR_SUSTAINED_Z_SCORE_AVG,
                    avg(col(AnomalyDetectionConstants.COL_ZSCORE_SCALED_AVG))
                    .over(windowspec)) \
        .withColumn(AnomalyDetectionConstants.COL_COUNT_OF_ANOMALIES_FOR_WINDOW,
                    sum(col(AnomalyDetectionConstants.COL_IS_ANOMALY))
                    .over(windowspec)) \
        .withColumn(AnomalyDetectionConstants.COL_IS_CELL_ANOMALOUS_IND,
                    when(((col(AnomalyDetectionConstants.COL_IS_ANOMALY) == 1) &
                          (col(AnomalyDetectionConstants.COL_COUNT_OF_ANOMALIES_FOR_WINDOW)
                           >= AnomalyDetectionConstants.MINIMUM_COUNT_OF_ANOMALIES_PER_WINDOW)),
                         1)
                    .otherwise(0)) \
        .withColumn(AnomalyDetectionConstants.COL_SUM_IS_CELL_ANOMALOUS_IND,
                    sum(col(AnomalyDetectionConstants.COL_IS_CELL_ANOMALOUS_IND))
                    .over(windowspec_for_anomalous_cells)) \
        .select(AnomalyDetectionConstants.COL_SUSTAINED_ZSCORE_OUTPUT)

    return zscore_sustained_df


# In[29]:


def filter_sustained_data(input_df):
    """ Filter out sustained data pertaining to the past 28 hours """
    sustained_data_df = input_df         .filter((col(AnomalyDetectionConstants.COL_TIMESTAMP)
                 .cast(AnomalyDetectionConstants.TIMESTAMP_DATATYPE) >=
                 lit(date_time).cast(AnomalyDetectionConstants.TIMESTAMP_DATATYPE)
                 - expr(AnomalyDetectionConstants.INTERVAL_28_HOURS)))

    return sustained_data_df


# In[30]:


def filter_sustained_anomalies(input_df):
    """ Filter out anomalous data"""
    sustained_anomalies_df = input_df         .filter(col(AnomalyDetectionConstants.COL_SUM_IS_CELL_ANOMALOUS_IND) >= 1)

    return sustained_anomalies_df


# In[31]:


def tabulate_data(input_df):
    """ Tabulate anomalous data """
    window_spec = Window.partitionBy(AnomalyDetectionConstants.COL_CELLNAME)         .orderBy(AnomalyDetectionConstants.COL_TIMESTAMP_EPOCH)

    check_continuous_df = input_df         .withColumn(AnomalyDetectionConstants.COL_NOT_IS_ANOMALY,
                    when(col(AnomalyDetectionConstants.COL_IS_ANOMALY) == 0, 1).otherwise(0)) \
        .withColumn(AnomalyDetectionConstants.COL_CUM_IS_NOT_ANOMALY,
                    sum(AnomalyDetectionConstants.COL_NOT_IS_ANOMALY).over(window_spec)) \
        .na.fill({AnomalyDetectionConstants.COL_CUM_IS_NOT_ANOMALY: 0})

    window_spec_for_merge = Window         .partitionBy(AnomalyDetectionConstants.COL_CELLNAME,
                     AnomalyDetectionConstants.COL_IS_ANOMALY,
                     AnomalyDetectionConstants.COL_CUM_IS_NOT_ANOMALY) \
        .orderBy(AnomalyDetectionConstants.COL_TIMESTAMP_EPOCH)

    window_spec_for_merge_latest = Window         .partitionBy(AnomalyDetectionConstants.COL_CELLNAME,
                     AnomalyDetectionConstants.COL_IS_ANOMALY,
                     AnomalyDetectionConstants.COL_CUM_IS_NOT_ANOMALY) \
        .orderBy(desc(AnomalyDetectionConstants.COL_TIMESTAMP_EPOCH))

    window_spec_for_last_n_windows = Window         .partitionBy(AnomalyDetectionConstants.COL_CELLNAME)         .orderBy(AnomalyDetectionConstants.COL_TIMESTAMP_EPOCH)         .rangeBetween(-1 * application_config.anomaly_detection.window_size_for_reporting
                      * 3600, 0)

    merged_df = check_continuous_df         .withColumn(AnomalyDetectionConstants.COL_LOWER_BOUND,
                    trunc_decimal
                    (col(AnomalyDetectionConstants.COL_CELL_HOURLY_AVG) +
                     (lit(application_config.anomaly_detection.lower_bound)
                      * col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV)))) \
        .withColumn(AnomalyDetectionConstants.COL_UPPER_BOUND,
                    trunc_decimal
                    (col(AnomalyDetectionConstants.COL_CELL_HOURLY_AVG) +
                     (lit(application_config.anomaly_detection.higher_bound)
                      * col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV)))) \
        .withColumn(AnomalyDetectionConstants.COL_TS_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_TIMESTAMP))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_KPI_LIST,
                    collect_list(
                        trunc_decimal(col(AnomalyDetectionConstants.COL_KPI_ACTUAL)))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_PROJECTED_KPI_LIST,
                    collect_list(
                        trunc_decimal(col(AnomalyDetectionConstants.COL_KPI)))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_SCALED_ZSCORE_LIST,
                    collect_list(
                        trunc_decimal(
                            col(AnomalyDetectionConstants.COL_ZSCORE_SCALED_AVG)))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_SUSTAINED_ZSCORE_LIST,
                    collect_list(
                        trunc_decimal
                        (col(AnomalyDetectionConstants.COL_AVG_FOR_SUSTAINED_Z_SCORE_AVG)))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_DIRECTION_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_DIRECTION))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_IS_ANOMALY_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_IS_ANOMALY))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR_LIST,
                    collect_list(
                        trunc_decimal(col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR)))
                    .over(window_spec_for_merge)) \
        .withColumn(AnomalyDetectionConstants.COL_TIME_WINDOW_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_TIMESTAMP))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_WINDOW_KPI_LIST,
                    collect_list(
                        trunc_decimal(col(AnomalyDetectionConstants.COL_KPI_ACTUAL)))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_WINDOW_PROJECTED_KPI_LIST,
                    collect_list(
                        trunc_decimal(col(AnomalyDetectionConstants.COL_KPI)))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_CELL_HOURLY_AVERAGE_LIST,
                    collect_list(
                        trunc_decimal(col(
                            AnomalyDetectionConstants.COL_CELL_HOURLY_AVG)))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV_LIST,
                    collect_list(
                        trunc_decimal(
                            col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV)))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_WINDOW_LOWER_BOUND_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_LOWER_BOUND))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_WINDOW_UPPER_BOUND_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_UPPER_BOUND))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_WINDOW_DIRECTION_LIST,
                    collect_list(
                        col(AnomalyDetectionConstants.COL_DIRECTION))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_WINDOW_ZSCORE_LIST,
                    collect_list(
                        trunc_decimal(col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR)))
                    .over(window_spec_for_last_n_windows)) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_MERGED_ANOMALY_IND,
                    row_number().over(window_spec_for_merge_latest)) \
        .withColumn(AnomalyDetectionConstants.COL_TS_SET,
                    size(collect_set(
                        col(AnomalyDetectionConstants.COL_TIMESTAMP))
                         .over(window_spec_for_merge))) \
        .filter(col(AnomalyDetectionConstants.COL_TS_SET) > 1) \
        .filter(col(AnomalyDetectionConstants.COL_LATEST_MERGED_ANOMALY_IND) == 1) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_CNT_OF_ANOMALIES,
                    size(col(AnomalyDetectionConstants.COL_TS_LIST))) \
        .select(AnomalyDetectionConstants.COLS_TMP_OUTPUT)

    return merged_df


# In[32]:


def tabulate_anomalous_observations(input_df, output_format):

    common_tabulated_df = input_df         .withColumn(AnomalyDetectionConstants.COL_START_TIME,
                    col(AnomalyDetectionConstants.COL_TS_LIST)[0]) \
        .withColumn(AnomalyDetectionConstants.COL_END_TIME,
                    last_element(col(AnomalyDetectionConstants.COL_TS_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_KPI,
                    last_element(col(AnomalyDetectionConstants.COL_KPI_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_PROJECTED_KPI,
                    last_element(
                        col(AnomalyDetectionConstants.COL_PROJECTED_KPI_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_SCALED_ZSCORE,
                    last_element(
                        col(AnomalyDetectionConstants.COL_SCALED_ZSCORE_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_SUSTAINED_ZSCORE,
                    last_element(
                        col(AnomalyDetectionConstants.COL_SUSTAINED_ZSCORE_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_DIRECTION,
                    last_element(
                        col(AnomalyDetectionConstants.COL_DIRECTION_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_IS_ANOMALY,
                    last_element(
                        col(AnomalyDetectionConstants.COL_IS_ANOMALY_LIST))) \
        .withColumn(AnomalyDetectionConstants.COL_LATEST_ZSCORE_CELL_HOUR,
                    last_element(
                        col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR_LIST)))

    if output_format == AnomalyDetectionConstants.FORMAT_CASSANDRA:
        tabulated_df = common_tabulated_df
    else:
        tabulated_df = common_tabulated_df             .withColumn(AnomalyDetectionConstants.COL_TS_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_TS_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_KPI_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_KPI_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_PROJECTED_KPI_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_PROJECTED_KPI_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_SCALED_ZSCORE_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_SCALED_ZSCORE_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_SUSTAINED_ZSCORE_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_SUSTAINED_ZSCORE_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_DIRECTION_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_DIRECTION_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_IS_ANOMALY_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_IS_ANOMALY_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_TIME_WINDOW_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_TIME_WINDOW_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_WINDOW_KPI_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_WINDOW_KPI_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_WINDOW_PROJECTED_KPI_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_WINDOW_PROJECTED_KPI_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_CELL_HOURLY_AVERAGE_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_CELL_HOURLY_AVERAGE_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_CELL_HOURLY_STDDEV_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_WINDOW_LOWER_BOUND_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_WINDOW_LOWER_BOUND_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_WINDOW_UPPER_BOUND_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_WINDOW_UPPER_BOUND_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_WINDOW_DIRECTION_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_WINDOW_DIRECTION_LIST))) \
            .withColumn(AnomalyDetectionConstants.COL_WINDOW_ZSCORE_LIST,
                        convert_list_to_array
                        (col(AnomalyDetectionConstants.COL_WINDOW_ZSCORE_LIST)))

    tabulated_df = rename_columns(
        tabulated_df,
        old_columns=[AnomalyDetectionConstants.COL_TS_LIST,
                     AnomalyDetectionConstants.COL_LATEST_ZSCORE_CELL_HOUR,
                     AnomalyDetectionConstants.COL_ZSCORE_CELL_HOUR_LIST
                     ],
        new_columns=[AnomalyDetectionConstants.COL_ANOMALY_TS_LIST,
                     AnomalyDetectionConstants.COL_LATEST_ZSCORE,
                     AnomalyDetectionConstants.COL_ZSCORE_LIST])

    tabulated_df = tabulated_df.select(AnomalyDetectionConstants.COLS_TABULATION_OUTPUT)         .withColumn(AnomalyDetectionConstants.COL_ANOMALY_SCORE,
                    col(AnomalyDetectionConstants.COL_LATEST_SUSTAINED_ZSCORE)
                    * col(AnomalyDetectionConstants.COL_LATEST_DIRECTION))

    return tabulated_df


# In[33]:


def filter_anomalous_data(input_df):
    """ Filter anomalous data """

    filtered_df_tmp = input_df         .filter((col(AnomalyDetectionConstants.COL_END_TIME)
                 .cast(AnomalyDetectionConstants.TIMESTAMP_DATATYPE) >=
                 lit(date_time)
                 .cast(AnomalyDetectionConstants.TIMESTAMP_DATATYPE)
                 - expr(AnomalyDetectionConstants.INTERVAL_4_HOURS)))

    if application_config.anomaly_detection.top_n == -1 and             application_config.anomaly_detection.bottom_n == -1:

        filtered_df = filtered_df_tmp
    else:
        pos_df = filtered_df_tmp                 .filter(col(AnomalyDetectionConstants.COL_LATEST_DIRECTION) == 1)
        neg_df = filtered_df_tmp             .filter(col(AnomalyDetectionConstants.COL_LATEST_DIRECTION) == -1)
        zero_kpi_df = filtered_df_tmp             .filter(col(AnomalyDetectionConstants.COL_LATEST_PROJECTED_KPI) == 0)

        if application_config.anomaly_detection.top_n != -1:
            pos_df = pos_df                 .orderBy(desc(AnomalyDetectionConstants.COL_LATEST_CNT_OF_ANOMALIES),
                         desc(AnomalyDetectionConstants.COL_LATEST_SUSTAINED_ZSCORE)) \
                .limit(application_config.anomaly_detection.top_n)

        if application_config.anomaly_detection.bottom_n != -1:
            neg_df = neg_df                 .orderBy(desc(AnomalyDetectionConstants.COL_LATEST_CNT_OF_ANOMALIES),
                         desc(AnomalyDetectionConstants.COL_LATEST_SUSTAINED_ZSCORE)) \
                .limit(application_config.anomaly_detection.bottom_n)

        filtered_df = pos_df             .union(neg_df).union(zero_kpi_df)

    return filtered_df


# In[34]:


def order_data(input_df, output_format):
    """ Order tabulated data """
    if output_format ==             AnomalyDetectionConstants.FORMAT_CASSANDRA:
        ordered_df = input_df
    else:
        ordered_df = input_df            .orderBy(asc(AnomalyDetectionConstants.COL_LATEST_DIRECTION),
                     desc(AnomalyDetectionConstants.COL_LATEST_CNT_OF_ANOMALIES),
                     desc(AnomalyDetectionConstants.COL_LATEST_SUSTAINED_ZSCORE)) \
            .coalesce(1)

    return ordered_df


# In[35]:


def convert_data_to_json_format(input_df):

    window_spec_for_datetime = Window.partitionBy(AnomalyDetectionConstants.COL_OBJECT_ID)         .orderBy(AnomalyDetectionConstants.COL_END_TIME) 
    json_input_df = rename_columns(
        input_df, old_columns=[AnomalyDetectionConstants.COL_CELLNAME],
        new_columns=[AnomalyDetectionConstants.COL_OBJECT_ID]
    )

    json_df = json_input_df         .withColumn(AnomalyDetectionConstants.COL_SCENARIO_ID,
                    lit(scenario_id)) \
        .withColumn(AnomalyDetectionConstants.COL_OBJECT_TYPE,
                    lit(AnomalyDetectionConstants.OBJECT_TYPE)) \
        .withColumn(AnomalyDetectionConstants.COL_ANOMALY_TYPE,
                    when(col(AnomalyDetectionConstants.COL_LATEST_DIRECTION) == 1,
                         (lit(scenario_id) * 100 + 1))
                    .otherwise((lit(scenario_id) * 100 + 2))) \
        .withColumn(AnomalyDetectionConstants.COL_SECONDS,
                    row_number().over(window_spec_for_datetime)) \
        .withColumn(AnomalyDetectionConstants.COL_DATE_TIME,
                    (current_timestamp().cast(AnomalyDetectionConstants.LONG_DATATYPE) +
                     col(AnomalyDetectionConstants.COL_SECONDS))
                    .cast(AnomalyDetectionConstants.TIMESTAMP_DATATYPE)) \
        .withColumn(AnomalyDetectionConstants.COL_IS_SCORED,
                    lit(AnomalyDetectionConstants.IS_SCORED)) \
        .drop(AnomalyDetectionConstants.COL_SECONDS)

    json_columns = [convert_to_camelcase(column) for column in json_df.columns]
    json_df = json_df.toDF(*json_columns)

    observation_columns_subset =         [convert_to_camelcase(column) for column in
         AnomalyDetectionConstants.OBSERVATION_COLUMNS_SUBSET]
    anomaly_details_columns =         [column for column in json_df.columns if column not in observation_columns_subset]
    observation_columns = [convert_to_camelcase(column)
                           for column in AnomalyDetectionConstants.OBSERVATION_COLUMNS]

    json_output_df = json_df         .withColumn(convert_to_camelcase(AnomalyDetectionConstants.COL_ANOMALY_DETAILS),
                    struct(anomaly_details_columns)) \
        .select(observation_columns)

    return json_output_df


# In[36]:


input_df = spark.read.option("header","true").csv("/persistent/evshkar/Mobily/data/pm/eric3g_voice/*.csv")

input_df_filtered = filter_source_data(input_df)


# In[37]:


input_df.filter(col("cellid").isin(['UXMK3508L','UXBV4893L'])).orderBy("cellid","ossdate","osshour").show(100, False)


# In[38]:


cell_stats_df = spark.read.option("header","true").csv("/persistent/evshkar/Mobily/data/pm/eric3g_voice_cell_stats/*.csv")
cell_hour_stats_df = spark.read.option("header","true").csv("/persistent/evshkar/Mobily/data/pm/eric3g_voice_cell_hour_stats/*.csv")


# In[39]:


cell_stats_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).show(10)


# In[40]:


cell_hour_stats_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","osshour").show(100)


# In[41]:


input_df_without_outages = filter_fm_alarms_data(input_df_filtered)


# In[42]:


input_df_without_outages.filter(col("cellid").isin(['UXMK3508L','UXBV4893L'])).orderBy("cellid","ossdate","osshour").show(100, False)


# In[43]:


processed_df = preprocess_data(input_df_without_outages)


# In[44]:


processed_df.filter(col("cellid").isin(['UXMK3508L','UXBV4893L'])).orderBy("cellid","ossdate","osshour").show(100, False)


# In[45]:


zscore_df = compute_zscores(processed_df, cell_hour_stats_df)


# In[46]:


zscore_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","ossdate","osshour").show(100, False)


# In[47]:


zscore_scaled_df = compute_scaled_zscores(zscore_df, cell_stats_df)


# In[48]:


zscore_scaled_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","ossdate","osshour").show(100, False)


# In[49]:


zscore_sustained_df = compute_sustained_zscores(zscore_scaled_df)


# In[50]:


zscore_sustained_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","ossdate","osshour").show(100, False)


# In[51]:


sustained_data_df = filter_sustained_data(zscore_sustained_df)


# In[52]:


sustained_data_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","ossdate","osshour").show(100, False)


# In[53]:


sustained_anomalies_df = filter_sustained_anomalies(sustained_data_df)


# In[54]:


sustained_anomalies_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","ossdate","osshour").show(100, False)


# In[55]:


tabulated_df = tabulate_data(sustained_anomalies_df)


# In[56]:


tabulated_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","ossdate","osshour").show(100, False)


# In[57]:


tabulated_output_df = tabulate_anomalous_observations(
                tabulated_df, application_config.anomaly_detection.output_format)


# In[58]:


filtered_df = filter_anomalous_data(tabulated_output_df)


# In[59]:


ordered_df = order_data(
                filtered_df, application_config.anomaly_detection.output_format)


# In[60]:


ordered_df.filter(col("CellName").isin(['UXMK3508L','UXBV4893L'])).orderBy("CellName","start_time").show(10, False)


# In[ ]:




